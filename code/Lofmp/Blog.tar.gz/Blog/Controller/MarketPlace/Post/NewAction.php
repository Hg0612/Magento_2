<?php 
/**
 * Landofcoder
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the landofcoder.com license that is
 * available through the world-wide-web at this URL:
 * http://landofcoder.com/license
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category   Landofcoder
 * @package    Lofmp_Blog
 * @copyright  Copyright (c) 2016 Landofcoder (http://www.landofcoder.com/)
 * @license    http://www.landofcoder.com/LICENSE-1.0.html
 */
namespace Lofmp\Blog\Controller\MarketPlace\Post; 

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Store\Model\StoreManager;

use Lofmp\Blog\Model\Post;
use Lofmp\Blog\Helper\Data;

class NewAction extends \Magento\Framework\App\Action\Action {

    protected $_resultPageFactory;

    protected $_postCollection;

    protected $_objectManager;

    protected $_helper;

    protected $_helper1;

    protected $_session = null;

    protected $_sellerFactory = null;
    
     protected $_frontendUrl;
    /**
     * [__construct description]
     * @param \Magento\Framework\App\Action\Context       $context               
     * @param \Magento\Framework\View\Result\PageFactory  $resultPageFactory     
     * @param \Lofmp\Blog\Model\Blog        $postCollection 
     * @param \Magento\Store\Model\StoreManager           $storeManager          
     * @param \Lofmp\Blog\Helper\Data               $helper                
     */
    public function __construct(
                Context            $context,
                PageFactory        $resultPageFactory,
                Post               $postCollection,
                StoreManager       $storeManager,
                Data               $helper,
                \Lof\MarketPlace\Helper\Data $helper1,
                \Magento\Customer\Model\Session $sellerSession,
                \Lof\MarketPlace\Model\SellerFactory $sellerFactory,
                \Magento\Framework\Url $frontendUrl
            )
    {

        $this->_resultPageFactory      = $resultPageFactory;
        $this->_postCollection = $postCollection;
        $this->_storeManager           = $storeManager;
        $this->_objectManager          = $context->getObjectManager();
        $this->_session = $sellerSession;
        $this->_sellerFactory = $sellerFactory;
        $this->_frontendUrl = $frontendUrl;
        $this->_helper1 = $helper1;
        parent::__construct($context);
    } 

       public function getFrontendUrl($route = '', $params = []){
        return $this->_frontendUrl->getUrl($route,$params);
    }
    /**
     * Index
     *
     * @return \Magento\Framework\View\Result\PageFactory
     */
    public function execute()
    {

       $resultRedirect = $this->resultRedirectFactory->create();

        $sellerId = $this->_session->getId();
        $status = $this->_sellerFactory->create()->load($sellerId,'customer_id')->getStatus();

        if ($this->_session->isLoggedIn() && $status == 1) {
            $this->_view->loadLayout();
            $this->_view->renderLayout();
        } elseif($this->_session->isLoggedIn() && $status == 0) {
            $this->_redirect ( $this->getFrontendUrl('lofmarketplace/seller/becomeseller') );
        } else {
            $this->messageManager->addNotice(__( 'You must have a seller account to access' ) );
            $this->_redirect ( $this->getFrontendUrl('lofmarketplace/seller/login') );
        }

        $id = str_replace('/','',$this->getRequest()->getParam('id'));
        $model = $this->_objectManager->create('Lofmp\Blog\Model\Post');

        if ($id) {
            $currentPost = $model->load($id);
            $currentPostId = $currentPost->getId();
            $currentPostSellerId = $currentPost->getSellerId();
            $seller_id = $this->_helper1->getSellerId();
            if (!$currentPostId || $currentPostSellerId != $seller_id) {
                $this->messageManager->addError(__('This post no longer exists.'));
                return $this->_redirect('blog/post/index');
            }
        }
       
    }
}