//jquery.Isotope file content
define(['jquery', 'Isotope', 'Lofmp_Blog/js/jquery-bridget'], function ($, Isotope) {
    'use strict';
    $.bridget('isotope', Isotope);
    return $;
});