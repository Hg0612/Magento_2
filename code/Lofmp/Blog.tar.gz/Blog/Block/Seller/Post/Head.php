<?php

namespace Lofmp\Blog\Block\Seller\Post;

class Head extends \Magento\Framework\View\Element\Template
{
	
    protected $request;

    /**
     * @param \Magento\Framework\View\Element\Template\Context
     * @param \Magento\Framework\Registry
     * @param \Lof\MarketPlace\Model\Seller
     * @param \Magento\Framework\App\ResourceConnection
     * @param array
    */
	public function __construct(
    	\Magento\Framework\View\Element\Template\Context $context,
        array $data = []
        ) {
        parent::__construct($context);

        $this->request = $context->getRequest();
    }
     
}