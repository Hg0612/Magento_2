<?php
/**
 * Landofcoder
 * 
 * NOTICE OF LICENSE
 * 
 * This source file is subject to the Landofcoder.com license that is
 * available through the world-wide-web at this URL:
 * http://Landofcoder.com/license
 * 
 * DISCLAIMER
 * 
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 * 
 * @category   Landofcoder
 * @package    Lofmp_Blog
 * @copyright  Copyright (c) 2016 Landofcoder (http://www.Landofcoder.com/)
 * @license    http://www.Landofcoder.com/LICENSE-1.0.html
 */
namespace Lofmp\Blog\Block\MarketPlace;

use Magento\Framework\View\Element\Template\Context;
use Lofmp\Blog\Helper\Data;
use Lofmp\Blog\Model\ResourceModel\Post\CollectionFactory;

class Post extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{

    protected $_postData;
    protected $_scopeConfig;
    protected $_postCollection;
    protected $_tagCollection;
    protected $_categoryCollection;
    protected $helper;
     

    public function __construct(
        \Lof\MarketPlace\Helper\Data $helper,
        Context       $context,
        Data          $postData,
        CollectionFactory  $postCollection,
        \Lofmp\Blog\Model\ResourceModel\Tag\CollectionFactory $tagCollection,
        \Lofmp\Blog\Model\ResourceModel\Category\Collection $categoryCollection,
        \Magento\Framework\App\Request\Http $request,
        array         $data = []  
        ) {
        $this->postData                = $postData;
        $this->_scopeConfig            = $context->getScopeConfig();
        $this->_postCollection         = $postCollection;
        $this->_tagCollection          = $tagCollection;
        $this->_categoryCollection     = $categoryCollection;
        $this->request = $request;
        $this->helper = $helper;
        parent::__construct($context, $data);
     
    }
   
    public function getConfig($key, $store = null)
    {
        $store = $this->_storeManager->getStore($store);
        $websiteId = $store->getWebsiteId();

        $result = $this->_scopeConfig->getValue(
            'post/' . $key,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store);
        return $result;
    }

    public function _prepareLayout() {
        $this->pageConfig->getTitle ()->set(__('New Post'));
        return parent::_prepareLayout ();
    }

    protected function _getSpaces($n)
    {
        $s = '';
        for($i = 0; $i < $n; $i++) {
            $s .= '--- ';
        }

        return $s;
    }

    public function drawItems($collection, $cat, $level = 0){
        foreach ($collection as $_cat) {
            if($_cat->getParentId() == $cat['id']){
                $cat1 = [
                    'label' => $_cat->getName(),
                    'value' => $_cat->getId(),
                    'id' => $_cat->getId(),
                    'parent_id' => $_cat->getParentId(),
                    'level' => 0,
                    'postion' => $_cat->getCatPosition()
                ];
                $children[] = $this->drawItems($collection, $cat1, $level+1);
                $cat['children'] = $children;
            }
        }
        $cat['level'] = $level;
        return $cat;
    }

    public function drawSpaces($cats){
        if(is_array($cats)){
            foreach ($cats as $k => $v) {
                $v['label'] = $this->_getSpaces($v['level']) . $v['label'];
                $this->_drawLevel[] = $v;
                if(isset($v['children']) && $children = $v['children']){
                    $this->drawSpaces($children);
                }
            }
        }
    }

    public function getCatCollection(){
        $id = $this->getRequest()->getParam('id');
        $collection = $this->_categoryCollection
        ->addFieldToFilter('seller_id',
            array(
                array('finset'=> array('0')),
                array('finset'=> array($this->helper->getSellerId())),
            )
        )
        ->setOrder('cat_position');
        return $collection;
    }

    public function getCats($categories, $cats = [], $level = 0){
        foreach ($cats as $k => $v) {

        }
    }

    public function getSellerCatCollection () {

        $collection = $this->getCatCollection();

        $cats = [];
        foreach ($collection as $_cat) {
            if(!$_cat->getParentId()){
                $cat = [
                    'label' => $_cat->getName(),
                    'value' => $_cat->getId(),
                    'id' => $_cat->getId(),
                    'parent_id' => $_cat->getParentId(),
                    'level' => 0,
                    'postion' => $_cat->getCatPosition()
                ];
                $cats[] = $this->drawItems($collection, $cat);
            }
        }
       $this->drawSpaces($cats);
       return $this->_drawLevel;
    }
   
}