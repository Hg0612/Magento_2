/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
 var config = {
     paths: {
        'jquery.Isotope': 'Lofmp_Blog/js/isotope.min',
        'jquery.Bridget': 'Lofmp_Blog/js/jquery-bridget'
    },
 	shim: {
        'Lofmp_Blog/js/jquery.shorten.min': {
            'deps': ['jquery']
        },
        'Lofmp_Blog/js/jquery.shorten': {
            'deps': ['jquery']
        }
    }
 };