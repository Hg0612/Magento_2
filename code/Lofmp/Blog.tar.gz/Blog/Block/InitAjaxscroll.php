<?php
/**
 * Landofcoder
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Landofcoder.com license that is
 * available through the world-wide-web at this URL:
 * http://landofcoder.com/license
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Landofcoder
 * @package    Lof_AjaxScroll
 *
 * @copyright  Copyright (c) 2016 Landofcoder (http://www.landofcoder.com/)
 * @license    http://www.landofcoder.com/LICENSE-1.0.html
 */

namespace Lofmp\Blog\Block;

class InitAjaxscroll extends \Magento\Framework\View\Element\Template
{   

    protected $coreRegistry = null;
    /**
     * @var Lofmp\Blog\Helper\Data
     */
    protected $helperData; 

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context    
     * @param \Lofmp\Blog\Helper\Data                      $helperData 
     * @param \Magento\Framework\Registry                      $registry   
     * @param array                                            $data       
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Lofmp\Blog\Helper\Data $helperData,
        \Magento\Framework\Registry $registry,
        array $data = []
        ) {
        parent::__construct($context, $data);  
        $this->helperData    = $helperData; 
        $this->coreRegistry = $registry;
    }

   

    public function isEnable() {
        $fullAction       = $this->getRequest()->getFullActionName();
        $enable_latest   = $this->helperData->getConfig('ajaxscroll_selectors/enable_latest');
        $enable_category = $this->helperData->getConfig('ajaxscroll_selectors/enable_category');
        $enable_search = $this->helperData->getConfig('ajaxscroll_selectors/enable_search');
        $enable_archive = $this->helperData->getConfig('ajaxscroll_selectors/enable_archive');
        $enable_tag = $this->helperData->getConfig('ajaxscroll_selectors/enable_tag');
        $enable_seller = $this->helperData->getConfig('ajaxscroll_selectors/enable_seller');
        $enable_comment = $this->helperData->getConfig('ajaxscroll_selectors/enable_comment');
        if (($enable_latest && $fullAction == 'lofmpblog_latest_view') || ($enable_category && $fullAction == 'lofmpblog_category_view')|| ($enable_search && $fullAction == 'lofmpblog_search_result')|| ($enable_archive && $fullAction == 'lofmpblog_archive_view')|| ($enable_tag && $fullAction == 'lofmpblog_tag_view')|| ($enable_seller && $fullAction == 'lofmpblog_seller_view')|| ($enable_comment && $fullAction == 'lofmpblog_post_view')) {
            return true;  
        }

        return false;
    } 

    /**
     * @return bool|false
     */
    public function getLoaderImage()
    {

        $url = $this->helperData->getConfig('ajaxscroll_selectors/loading_image');
        if(!empty($url)) {
            $url = strpos($url, 'http') === 0 ? $url : $this->getViewFileUrl($url);
        } 
        return empty($url) ? false : $url;
    }
}
